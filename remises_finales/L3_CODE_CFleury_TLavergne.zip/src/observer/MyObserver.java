package observer;

public interface MyObserver {
    public void update();
}
