package controller;


public abstract class ImageCommand {

    public abstract void executeAction(java.awt.Image img,String path);

}
